local downedAt = {}
local calls = {}
local cooldownUntil = {}
local voiceMuted = {}

local function GetPlayer(src)
    local name = Framework.Name()
    if name == 'qbox' then
        local ok, player = pcall(function()
            return exports.qbx_core:GetPlayer(src)
        end)
        if ok and player then
            return { kind = 'qbox', raw = player }
        end
    end

    if name == 'qb' or name == 'qbox' then
        local core = Framework.Object()
        local player = core and core.Functions and core.Functions.GetPlayer(src)
        if player then
            return { kind = name == 'qbox' and 'qbox' or 'qb', raw = player }
        end
        return nil
    end

    if name == 'esx' then
        local ESX = Framework.Object()
        local player = ESX and ESX.GetPlayerFromId(src)
        if player then
            return { kind = 'esx', raw = player }
        end
    end
end

local function SetVoiceMuted(src, muted)
    if not Config.MuteWhileDead then return end
    muted = muted and true or false
    if voiceMuted[src] == muted then return end
    voiceMuted[src] = muted

    MumbleSetPlayerMuted(src, muted)

    if GetResourceState('pma-voice') == 'started' then
        pcall(function()
            exports['pma-voice']:setPlayerMuted(src, muted)
        end)
    end

    TriggerClientEvent('tees-npcmedic:client:voice', src, muted)
end

local function Notify(src, message, kind)
    kind = kind or 'primary'
    local name = Framework.Name()
    if name == 'esx' then
        TriggerClientEvent('esx:showNotification', src, message)
        return
    end
    if name == 'qbox' then
        local qboxKind = kind == 'primary' and 'inform' or kind
        local ok = pcall(function()
            exports.qbx_core:Notify(src, message, qboxKind)
        end)
        if ok then return end
    end
    TriggerClientEvent('QBCore:Notify', src, message, kind)
end

local function IsDown(src, player)
    local state = Player(src).state
    local death = state['qbx_medical:deathState']
    if death and death ~= 1 then return true end
    if state.isDead or state.dead or state.isdead then return true end

    if player.kind ~= 'esx' then
        local meta = player.raw.PlayerData.metadata or {}
        if meta.isdead then return true end
        if Config.IncludeLaststand and meta.inlaststand then return true end
    end

    local ped = GetPlayerPed(src)
    if ped and ped ~= 0 then
        local health = GetEntityHealth(ped)
        if health <= 101 then return true end
    end
    return false
end

local function EachPlayer(fn)
    local name = Framework.Name()
    if name == 'esx' then
        local ESX = Framework.Object()
        if not ESX or not ESX.GetExtendedPlayers then return end
        for _, xPlayer in pairs(ESX.GetExtendedPlayers()) do
            fn({ kind = 'esx', raw = xPlayer })
        end
        return
    end

    if name == 'qbox' then
        local ok, players = pcall(function()
            return exports.qbx_core:GetQBPlayers()
        end)
        if ok and players then
            for _, ply in pairs(players) do
                fn({ kind = 'qbox', raw = ply })
            end
            return
        end
    end

    local core = Framework.Object()
    if not core or not core.Functions then return end
    if core.Functions.GetQBPlayers then
        for _, ply in pairs(core.Functions.GetQBPlayers()) do
            fn({ kind = 'qb', raw = ply })
        end
        return
    end
    for _, id in pairs(core.Functions.GetPlayers()) do
        local ply = core.Functions.GetPlayer(id)
        if ply then fn({ kind = 'qb', raw = ply }) end
    end
end

local function JobOf(player)
    if player.kind == 'esx' then
        return player.raw.job
    end
    return player.raw.PlayerData and player.raw.PlayerData.job
end

local function EmsOnDuty()
    if not Config.MaxOnDutyEms or Config.MaxOnDutyEms < 0 then
        return 0
    end

    local count = 0
    EachPlayer(function(ply)
        local job = JobOf(ply)
        if not job or job.name ~= Config.EmsJob then return end
        local duty = job.onduty
        if duty == nil then duty = job.onDuty end
        if duty == nil or duty then
            count = count + 1
        end
    end)
    return count
end

local function RemainingLockout(src)
    local started = downedAt[src]
    if not started then return Config.CallDelay end
    local left = Config.CallDelay - (os.time() - started)
    if left < 0 then left = 0 end
    return left
end

local function Balance(player, account)
    account = Framework.Account(account)
    if not account or account == '' then return 0 end
    if player.kind == 'esx' then
        local acc = player.raw.getAccount(account)
        return acc and acc.money or 0
    end
    return player.raw.Functions.GetMoney(account) or 0
end

local function TakeMoney(player, account, amount)
    account = Framework.Account(account)
    if player.kind == 'esx' then
        if Balance(player, account) < amount then return false end
        player.raw.removeAccountMoney(account, amount, 'npc-medic')
        return true
    end
    return player.raw.Functions.RemoveMoney(account, amount, 'npc-medic')
end

local function GiveMoney(player, account, amount)
    account = Framework.Account(account)
    if player.kind == 'esx' then
        player.raw.addAccountMoney(account, amount, 'npc-medic-refund')
        return
    end
    player.raw.Functions.AddMoney(account, amount, 'npc-medic-refund')
end

local function Charge(player)
    local cost = tonumber(Config.Cost) or 0
    if cost <= 0 then
        return true, nil, 0
    end

    local function tryAccount(account)
        if not account or account == false or account == '' then return false end
        if Balance(player, account) < cost then return false end
        return TakeMoney(player, account, cost)
    end

    if tryAccount(Config.Account) then
        return true, Config.Account, cost
    end
    if Config.FallbackAccount and Config.FallbackAccount ~= Config.Account and tryAccount(Config.FallbackAccount) then
        return true, Config.FallbackAccount, cost
    end
    return false, nil, cost
end

local function Refund(src)
    local call = calls[src]
    if not call or not call.account or not call.cost or call.cost <= 0 or call.refunded then
        return
    end
    local player = GetPlayer(src)
    if not player then return end
    GiveMoney(player, call.account, call.cost)
    call.refunded = true
end

local function ClearCall(src, refund)
    if refund then Refund(src) end
    calls[src] = nil
end

local function ClearDownMetadata(player)
    if player.kind == 'esx' or not player.raw.Functions or not player.raw.Functions.SetMetaData then
        return
    end
    local meta = player.raw.PlayerData.metadata or {}
    player.raw.Functions.SetMetaData('isdead', false)
    player.raw.Functions.SetMetaData('inlaststand', false)
    player.raw.Functions.SetMetaData('health', Config.ReviveHealth)
    if meta.bleeding ~= nil then
        player.raw.Functions.SetMetaData('bleeding', false)
    end
    if meta.injuries ~= nil then
        player.raw.Functions.SetMetaData('injuries', {})
    end
    if meta.bleedlevel ~= nil then
        player.raw.Functions.SetMetaData('bleedlevel', 0)
    end
end

local function ApplyFrameworkRevive(src, player)
    local medical = Framework.Medical()

    if medical == 'qbox' then
        ClearDownMetadata(player)
        local ok = pcall(function()
            exports.qbx_medical:Revive(src)
        end)
        if not ok then
            TriggerClientEvent('qbx_medical:client:playerRevived', src)
        end
        return medical
    end

    if medical == 'esx_death' then
        local ok = pcall(function()
            exports.esx_death:Revive(src, 'npc-medic')
        end)
        if not ok then
            TriggerClientEvent('esx_ambulancejob:revive', src)
        end
        return medical
    end

    if medical == 'esx' or Framework.Name() == 'esx' then
        TriggerClientEvent('esx_ambulancejob:revive', src)
        return 'esx'
    end

    ClearDownMetadata(player)
    return 'qb'
end

RegisterNetEvent('tees-npcmedic:server:downed', function()
    local src = source
    local player = GetPlayer(src)
    if not player then return end
    if not IsDown(src, player) then
        TriggerClientEvent('tees-npcmedic:client:ignored', src)
        return
    end

    if not downedAt[src] then
        downedAt[src] = os.time()
    end

    local remaining = RemainingLockout(src)
    local cool = cooldownUntil[src]
    if cool and cool > os.time() then
        local coolLeft = cool - os.time()
        if coolLeft > remaining then remaining = coolLeft end
    end

    TriggerClientEvent('tees-npcmedic:client:begin', src, remaining, Config.CallDelay)
    SetVoiceMuted(src, true)
end)

RegisterNetEvent('tees-npcmedic:server:request', function()
    local src = source
    local player = GetPlayer(src)
    if not player then return end

    if calls[src] then
        local age = os.time() - (calls[src].at or os.time())
        local maxAge = (Config.Medic.arriveTimeout or 30) + (Config.TreatTime or 12) + 30
        if age > maxAge then
            ClearCall(src, true)
        else
            return
        end
    end

    if not IsDown(src, player) then
        Notify(src, 'You are not down.', 'error')
        TriggerClientEvent('tees-npcmedic:client:rejected', src)
        return
    end

    if not downedAt[src] then
        downedAt[src] = os.time()
    end

    local remaining = RemainingLockout(src)
    local cool = cooldownUntil[src]
    if cool and cool > os.time() then
        local coolLeft = cool - os.time()
        if coolLeft > remaining then
            Notify(src, Config.Text.cooldown, 'error')
            TriggerClientEvent('tees-npcmedic:client:rejected', src, coolLeft)
            return
        end
    end

    if remaining > 0 then
        Notify(src, Config.Text.tooSoon, 'error')
        TriggerClientEvent('tees-npcmedic:client:rejected', src, remaining)
        return
    end

    if Config.MaxOnDutyEms and Config.MaxOnDutyEms >= 0 and EmsOnDuty() > Config.MaxOnDutyEms then
        Notify(src, Config.Text.emsOnline, 'error')
        TriggerClientEvent('tees-npcmedic:client:rejected', src)
        return
    end

    local paid, account, cost = Charge(player)
    if not paid then
        Notify(src, Config.Text.noMoney, 'error')
        TriggerClientEvent('tees-npcmedic:client:rejected', src)
        return
    end

    if cost > 0 and account then
        local label = (account == 'cash' or account == 'money') and 'cash' or 'bank'
        local formatted = tostring(math.floor(cost))
        local replaced
        repeat
            formatted, replaced = formatted:gsub('^(-?%d+)(%d%d%d)', '%1,%2')
        until replaced == 0
        Notify(src, ('Charged $%s from %s.'):format(formatted, label), 'success')
    end

    calls[src] = {
        stage = 'dispatched',
        at = os.time(),
        account = account,
        cost = cost,
        refunded = false,
    }

    TriggerClientEvent('tees-npcmedic:client:dispatch', src)
end)

RegisterNetEvent('tees-npcmedic:server:treatment', function()
    local src = source
    local call = calls[src]
    if not call or call.stage ~= 'dispatched' then return end
    call.stage = 'treating'
    call.treatAt = os.time()
end)

RegisterNetEvent('tees-npcmedic:server:finish', function()
    local src = source
    local player = GetPlayer(src)
    local call = calls[src]
    if not player or not call then return end

    if os.time() - (call.at or os.time()) < 4 then return end

    calls[src] = nil
    downedAt[src] = nil
    if Config.Cooldown and Config.Cooldown > 0 then
        cooldownUntil[src] = os.time() + Config.Cooldown
    end

    local medical = ApplyFrameworkRevive(src, player)
    TriggerClientEvent('tees-npcmedic:client:revive', src, Config.ReviveHealth, medical)
    SetVoiceMuted(src, false)
end)

RegisterNetEvent('tees-npcmedic:server:failed', function()
    local src = source
    local call = calls[src]
    if not call then return end
    if call.stage == 'treating' then return end
    ClearCall(src, true)
    Notify(src, Config.Text.failed, 'error')
end)

RegisterNetEvent('tees-npcmedic:server:syncVoice', function()
    local src = source
    local player = GetPlayer(src)
    if not player then return end
    SetVoiceMuted(src, IsDown(src, player))
end)

RegisterNetEvent('tees-npcmedic:server:cancel', function()
    local src = source
    ClearCall(src, true)
    downedAt[src] = nil
    SetVoiceMuted(src, false)
end)

AddEventHandler('playerDropped', function()
    local src = source
    ClearCall(src, true)
    downedAt[src] = nil
    cooldownUntil[src] = nil
    voiceMuted[src] = nil
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for src, muted in pairs(voiceMuted) do
        if muted then
            MumbleSetPlayerMuted(src, false)
        end
    end
end)

AddEventHandler('onResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    print(('^2[tees-npcmedic]^7 field medic ready (%s / %s)'):format(Framework.Name(), Framework.Medical()))
end)
