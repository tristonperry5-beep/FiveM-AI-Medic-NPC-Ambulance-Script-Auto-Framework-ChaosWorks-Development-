const root = document.getElementById('root');
const statusEl = document.getElementById('status');
const bpmEl = document.getElementById('bpm');
const timerEl = document.getElementById('timer');
const timerLabel = document.getElementById('timerLabel');
const barLabel = document.getElementById('barLabel');
const barValue = document.getElementById('barValue');
const fill = document.getElementById('fill');
const heart = document.getElementById('heart');
const flash = document.getElementById('flash');
const canvas = document.getElementById('ecg');
const ctx2d = canvas.getContext('2d');

function runningInGame() {
    const href = (window.location && window.location.href) || '';
    if (href.indexOf('nui://') === 0 || href.indexOf('cfx-nui-') !== -1) return true;
    if (typeof window.invokeNative === 'function') return true;
    return typeof GetParentResourceName === 'function';
}

const inGame = runningInGame();

let state = 'waiting';
let soundOn = true;
let running = false;
let raf = 0;
let last = 0;
let bpm = 38;
let targetBpm = 36;
let phase = 0.35;
let carry = 0;
let head = 0;
let samples = new Float32Array(800);
let width = 480;
let height = 96;

let lockStart = 0;
let lockLeft = 30;
let lockTotal = 30;
let treatStart = 0;
let treatDur = 12000;
let meters = null;
let audioCtx = null;
let beatArmed = true;

const speech = document.getElementById('speech');
const speechLine = document.getElementById('speechLine');
let talkLines = [
    'Hey. Can you hear me? Stay with me.',
    'Checking your airway. Don\'t move.',
    'Airway is clear. I\'m checking for a pulse.',
    'Pulse is there, but it\'s weak.',
    'You\'re bleeding. I\'m packing that now.',
    'Starting compressions. One, two, three...',
    'Keep going. Come on, breathe for me.',
    'I\'ve got a rhythm. Stay with it.',
    'Pupils are responding. Almost there.',
    'You\'re coming back. Easy, easy.',
    'That\'s it. You\'re stable. I\'ve got you.',
];

function setTalk(line) {
    if (!line) {
        speech.hidden = true;
        speechLine.textContent = '';
        return;
    }
    if (speechLine.textContent !== line) {
        speechLine.textContent = line;
        speech.classList.remove('show');
        void speech.offsetWidth;
        speech.classList.add('show');
    }
    speech.hidden = false;
}

function hideTalk() {
    setTalk('');
}

const copy = {
    waiting: ['Critical', 'Call lockout', 'Response window'],
    ready: ['Signal weak', 'Medic ready', 'Response window'],
    enroute: ['Medic en route', 'Unit responding', 'Responding'],
    treating: ['CPR in progress', 'Treatment', 'Revive'],
    revived: ['Stable', 'Sinus rhythm', 'Revive'],
};

function prefill() {
    let cursor = 0.2;
    const step = (Math.max(bpm, 28) / 60) / 92;
    for (let i = 0; i < width; i++) {
        cursor += step;
        if (cursor >= 1) cursor -= 1;
        samples[i] = ecgShape(cursor);
    }
    phase = cursor;
    head = 0;
}

function resize() {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = Math.max(120, Math.floor(rect.width));
    height = Math.max(48, Math.floor(rect.height));
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    ctx2d.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (samples.length !== width) {
        samples = new Float32Array(width);
        prefill();
    }
}

function fmt(seconds) {
    const s = Math.max(0, Math.ceil(seconds));
    const m = Math.floor(s / 60);
    const r = s % 60;
    return String(m).padStart(2, '0') + ':' + String(r).padStart(2, '0');
}

function pct(value) {
    return Math.round(Math.max(0, Math.min(1, value)) * 100) + '%';
}

function setBar(progress, indeterminate) {
    if (indeterminate) {
        fill.classList.add('indet');
        fill.style.transform = '';
        return;
    }
    fill.classList.remove('indet');
    fill.style.transform = 'scaleX(' + Math.max(0, Math.min(1, progress)) + ')';
}

function applyCopy() {
    const row = copy[state] || copy.waiting;
    statusEl.textContent = row[0];
    timerLabel.textContent = row[1];
    barLabel.textContent = row[2];
    root.dataset.state = state;
}

function ecgShape(p) {
    const q = Math.exp(-((p - 0.15) ** 2) / 0.00045) * -0.16;
    const r = Math.exp(-((p - 0.185) ** 2) / 0.00009) * 1;
    const s = Math.exp(-((p - 0.225) ** 2) / 0.0005) * -0.28;
    const t = Math.exp(-((p - 0.42) ** 2) / 0.0032) * 0.2;
    const pw = Math.exp(-((p - 0.075) ** 2) / 0.001) * 0.09;
    return q + r + s + t + pw;
}

function ensureAudio() {
    if (!soundOn) return null;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return null;
    if (!audioCtx) audioCtx = new Ctx();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    return audioCtx;
}

function beep() {
    const ctx = ensureAudio();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.value = state === 'treating' || state === 'revived' ? 1040 : 760;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.045, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.08);
}

function onBeat() {
    heart.classList.remove('thump');
    void heart.offsetWidth;
    heart.classList.add('thump');
    flash.classList.add('on');
    setTimeout(() => flash.classList.remove('on'), 70);
    beep();
}

function draw() {
    ctx2d.clearRect(0, 0, width, height);
    ctx2d.beginPath();
    const mid = height * 0.58;
    const amp = height * 0.34;
    for (let i = 0; i < width; i++) {
        const idx = (head + i) % width;
        const y = mid - samples[idx] * amp;
        if (i === 0) ctx2d.moveTo(i, y);
        else ctx2d.lineTo(i, y);
    }
    ctx2d.strokeStyle = getComputedStyle(root).getPropertyValue('--accent').trim() || '#ff5d73';
    ctx2d.lineWidth = 2;
    ctx2d.shadowColor = ctx2d.strokeStyle;
    ctx2d.shadowBlur = 8;
    ctx2d.stroke();
    ctx2d.shadowBlur = 0;

    const tip = (head + width - 1) % width;
    const tipY = mid - samples[tip] * amp;
    ctx2d.fillStyle = '#f4fffb';
    ctx2d.beginPath();
    ctx2d.arc(width - 1, tipY, 2.4, 0, Math.PI * 2);
    ctx2d.fill();
}

function lockRemaining(now) {
    const elapsed = (now - lockStart) / 1000;
    return Math.max(0, lockLeft - elapsed);
}

function updateReadout(now) {
    bpmEl.textContent = String(Math.round(bpm));

    if (state === 'waiting' || state === 'ready') {
        hideTalk();
        const rem = lockRemaining(now);
        if (state === 'waiting' && rem <= 0) {
            setReady();
            return;
        }
        const done = lockTotal <= 0 ? 1 : (lockTotal - rem) / lockTotal;
        timerEl.textContent = fmt(rem);
        setBar(state === 'ready' ? 1 : done, false);
        barValue.textContent = state === 'ready' ? 'Ready' : pct(done);
        targetBpm = state === 'ready' ? 22 : 34 - (1 - rem / Math.max(lockTotal, 1)) * 8;
        return;
    }

    if (state === 'enroute') {
        hideTalk();
        timerEl.textContent = meters == null ? '--' : meters + 'm';
        setBar(0, true);
        barValue.textContent = 'Live';
        targetBpm = 30;
        return;
    }

    if (state === 'treating') {
        const p = Math.max(0, Math.min(1, (now - treatStart) / treatDur));
        timerEl.textContent = pct(p);
        setBar(p, false);
        barValue.textContent = pct(p);
        targetBpm = 28 + p * 52;
        const count = talkLines.length;
        const index = Math.min(count - 1, Math.floor(p * count));
        setTalk(talkLines[index]);
        return;
    }

    timerEl.textContent = fmt(0);
    setBar(1, false);
    barValue.textContent = '100%';
    targetBpm = 84;
}

function frame(now) {
    if (!running) return;
    if (!last) last = now;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;

    bpm += (targetBpm - bpm) * Math.min(1, dt * 1.4);
    if (bpm < 16) bpm = 16;

    const pxPerSec = 92;
    carry += pxPerSec * dt;
    const irregular = bpm < 40;
    while (carry >= 1) {
        carry -= 1;
        phase += (bpm / 60) / pxPerSec;
        if (phase >= 1) {
            phase -= Math.floor(phase);
            if (beatArmed) onBeat();
        }
        let sample = ecgShape(phase);
        if (irregular) sample += (Math.random() - 0.5) * 0.05;
        samples[head] = sample;
        head = (head + 1) % width;
    }

    updateReadout(now);
    draw();
    raf = requestAnimationFrame(frame);
}

function start() {
    resize();
    if (running) return;
    running = true;
    last = 0;
    raf = requestAnimationFrame(frame);
}

function stop() {
    running = false;
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
}

function show() {
    root.hidden = false;
    start();
    requestAnimationFrame(resize);
}

function openMonitor(data) {
    soundOn = data.sound !== false;
    state = 'waiting';
    meters = null;
    lockTotal = Number(data.delay) > 0 ? Number(data.delay) : 30;
    lockLeft = Number.isFinite(Number(data.remaining)) ? Number(data.remaining) : lockTotal;
    lockStart = performance.now();
    const progressed = lockTotal <= 0 ? 1 : 1 - lockLeft / lockTotal;
    bpm = 40 - progressed * 10;
    targetBpm = bpm;
    beatArmed = true;
    applyCopy();
    show();
    if (lockLeft <= 0) setReady();
}

function setReady() {
    state = 'ready';
    applyCopy();
    show();
}

function setEnroute() {
    state = 'enroute';
    meters = null;
    applyCopy();
    show();
}

function setTreat(duration, lines) {
    state = 'treating';
    treatDur = Number(duration) > 0 ? Number(duration) : 12000;
    treatStart = performance.now();
    if (Array.isArray(lines) && lines.length) talkLines = lines;
    applyCopy();
    show();
}

function setRevived() {
    state = 'revived';
    applyCopy();
    setTalk(talkLines[talkLines.length - 1] || 'You\'re okay. Easy now.');
    show();
}

function closeMonitor() {
    stop();
    hideTalk();
    root.hidden = true;
    state = 'waiting';
}

function apply(data) {
    if (!data || !data.action) return;
    if (data.action === 'open') openMonitor(data);
    else if (data.action === 'ready') setReady();
    else if (data.action === 'enroute') setEnroute();
    else if (data.action === 'distance') meters = Number(data.meters) || 0;
    else if (data.action === 'treat') setTreat(data.duration, data.lines);
    else if (data.action === 'revived') setRevived();
    else if (data.action === 'close') closeMonitor();
    if (Number.isFinite(Number(data.meters))) meters = Number(data.meters);
}

window.addEventListener('message', (event) => apply(event.data || {}));

window.addEventListener('resize', resize);

if (inGame) {
    fetch('https://' + GetParentResourceName() + '/ready', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: '{}',
    }).then((response) => response.json()).then(apply).catch(() => {});
}

if (!inGame && new URLSearchParams(location.search).get('preview') === '1') {
    document.documentElement.classList.add('preview');
    const tools = document.getElementById('previewTools');
    tools.hidden = false;
    const buttons = tools.querySelectorAll('button');

    function preview(name) {
        buttons.forEach((button) => {
            button.classList.toggle('active', button.dataset.state === name);
        });
        if (name === 'waiting') {
            const raw = params.get('left');
            const left = raw == null ? 18 : Number(raw);
            openMonitor({ remaining: Number.isFinite(left) ? left : 18, delay: 30, sound: false });
        }
        if (name === 'ready') {
            openMonitor({ remaining: 0, delay: 30, sound: false });
            setReady();
        }
        if (name === 'enroute') {
            setEnroute();
            meters = 42;
        }
        if (name === 'treating') setTreat(25000);
        if (name === 'revived') setRevived();
    }

    buttons.forEach((button) => {
        button.addEventListener('click', () => preview(button.dataset.state));
    });

    const params = new URLSearchParams(location.search);
    preview(params.get('state') || 'waiting');
    if (params.get('chrome') === '0') tools.hidden = true;
}
