local phase = 'idle'
local reported = false
local previewing = false
local uiOpen = false
local currentRun = 0
local units = {}
local uiState = { action = 'close' }
local medicTalk = nil

local function Notify(message, kind)
    kind = kind or 'primary'
    local name = Framework.Name()
    if name == 'esx' then
        local ESX = Framework.Object()
        if ESX and ESX.ShowNotification then
            ESX.ShowNotification(message)
        end
        return
    end
    if name == 'qbox' then
        local ok = pcall(function()
            exports.qbx_core:Notify(message, kind == 'primary' and 'inform' or kind)
        end)
        if ok then return end
    end
    local core = Framework.Object()
    if core and core.Functions and core.Functions.Notify then
        core.Functions.Notify(message, kind)
    end
end

local function IsLoaded()
    local name = Framework.Name()
    if name == 'esx' then
        local ESX = Framework.Object()
        if ESX and ESX.IsPlayerLoaded then
            return ESX.IsPlayerLoaded()
        end
    end
    return LocalPlayer.state.isLoggedIn == true
end

local function PlayerData()
    local name = Framework.Name()
    if name == 'esx' then
        local ESX = Framework.Object()
        return ESX and ESX.GetPlayerData and ESX.GetPlayerData() or nil
    end
    if name == 'qbox' then
        local ok, data = pcall(function()
            return exports.qbx_core:GetPlayerData()
        end)
        if ok and data then return data end
    end
    local core = Framework.Object()
    if core and core.Functions and core.Functions.GetPlayerData then
        return core.Functions.GetPlayerData()
    end
end

local function SendUI(payload)
    if payload.action == 'distance' then
        uiState.meters = payload.meters
    else
        uiState = payload
    end
    SendNUIMessage(payload)
end

local function DeathState()
    return LocalPlayer.state['qbx_medical:deathState']
end

local function IsLocalDown()
    if not IsLoaded() then return false end

    local ped = PlayerPedId()
    local state = LocalPlayer.state
    local death = DeathState()
    -- Qbox keeps a full health bar while the death state is still laststand or dead.
    if death and death ~= 1 then return true end
    if state.isDead or state.dead or state.isdead then return true end
    if IsEntityDead(ped) or IsPedFatallyInjured(ped) then return true end

    local name = Framework.Name()
    if name == 'esx' then
        return GetEntityHealth(ped) <= 0
    end

    local data = PlayerData()
    if not data or not data.citizenid then return false end

    local meta = data.metadata or {}
    if meta.isdead then return true end
    if Config.IncludeLaststand and meta.inlaststand then return true end
    if GetEntityHealth(ped) >= 190 then return false end
    return false
end

local function Track(unit)
    units[unit] = true
    return unit
end

local function Forget(unit)
    if unit then units[unit] = nil end
end

local function DeleteUnitNow(unit)
    if not unit then return end
    Forget(unit)
    if unit.blip and DoesBlipExist(unit.blip) then
        RemoveBlip(unit.blip)
    end
    if unit.ped and DoesEntityExist(unit.ped) then
        DeleteEntity(unit.ped)
    end
    if unit.veh and DoesEntityExist(unit.veh) then
        DeleteEntity(unit.veh)
    end
end

local lingering = {}

local function RemoveOwnedEntity(entity)
    if not entity or entity == 0 or not DoesEntityExist(entity) then return end
    SetEntityAsMissionEntity(entity, true, true)
    local deadline = GetGameTimer() + 1000
    NetworkRequestControlOfEntity(entity)
    while not NetworkHasControlOfEntity(entity) and GetGameTimer() < deadline do
        NetworkRequestControlOfEntity(entity)
        Wait(0)
    end
    SetEntityAsMissionEntity(entity, true, true)
    DeleteEntity(entity)
end

local ParkAmbulance
local EnsureAmbulance

local function HoldVehicle(veh)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end
    SetEntityAsMissionEntity(veh, true, true)
    SetVehicleHasBeenOwnedByPlayer(veh, true)
    SetEntityInvincible(veh, true)
    SetVehicleCanBeVisiblyDamaged(veh, false)
    SetEntityCanBeDamaged(veh, false)
    pcall(function()
        SetEntityDistanceCullingRadius(veh, 250.0)
    end)
    if NetworkGetEntityIsNetworked(veh) then
        local netId = NetworkGetNetworkIdFromEntity(veh)
        if netId and netId ~= 0 then
            SetNetworkIdCanMigrate(netId, false)
        end
    end
end

local function DismissUnit(unit)
    if not unit then return end
    lingering[unit] = true
    Forget(unit)
    CreateThread(function()
        local ped, veh, blip = unit.ped, unit.veh, unit.blip
        if ped and DoesEntityExist(ped) then
            FreezeEntityPosition(ped, false)
            SetPedCanRagdoll(ped, false)
            ClearPedTasksImmediately(ped)
            SetBlockingOfNonTemporaryEvents(ped, true)
            SetPedKeepTask(ped, true)
        end

        local playerCoords = GetEntityCoords(PlayerPedId())
        if EnsureAmbulance then
            veh = EnsureAmbulance(unit, playerCoords) or veh
        end

        if veh and DoesEntityExist(veh) then
            HoldVehicle(veh)
            if ParkAmbulance and #(GetEntityCoords(veh) - playerCoords) > 18.0 then
                ParkAmbulance(veh, playerCoords)
            end
            SetVehicleDoorsLocked(veh, 1)
            SetVehicleEngineOn(veh, true, true, false)
            SetVehicleSiren(veh, false)
            SetVehicleUndriveable(veh, false)

            if ped and DoesEntityExist(ped) and not IsPedInVehicle(ped, veh, false) then
                TaskEnterVehicle(ped, veh, 6000, -1, 2.0, 1, 0)
                local deadline = GetGameTimer() + 6000
                while GetGameTimer() < deadline and DoesEntityExist(ped) and DoesEntityExist(veh) and not IsPedInVehicle(ped, veh, false) do
                    Wait(200)
                end
                if DoesEntityExist(ped) and DoesEntityExist(veh) and not IsPedInVehicle(ped, veh, false) then
                    ClearPedTasksImmediately(ped)
                    SetPedIntoVehicle(ped, veh, -1)
                end
            end

            if ped and DoesEntityExist(ped) and DoesEntityExist(veh) and IsPedInVehicle(ped, veh, false) then
                local dest = GetOffsetFromEntityInWorldCoords(veh, 0.0, 80.0, 0.0)
                TaskVehicleDriveToCoord(ped, veh, dest.x, dest.y, dest.z, 18.0, 0, GetEntityModel(veh), 786603, 8.0, true)
                Wait(8000)
            end
        end

        if blip and DoesBlipExist(blip) then RemoveBlip(blip) end
        RemoveOwnedEntity(ped)
        RemoveOwnedEntity(veh)
        lingering[unit] = nil
    end)
end

local function CloseUI()
    if not uiOpen then return end
    uiOpen = false
    SendUI({ action = 'close' })
end

local function OpenUI(remaining, delay)
    uiOpen = true
    SendUI({
        action = 'open',
        remaining = remaining,
        delay = delay or Config.CallDelay,
        sound = Config.Sound,
    })
end

local function LoadModel(model)
    local hash = type(model) == 'string' and joaat(model) or model
    if not IsModelInCdimage(hash) or not IsModelValid(hash) then
        return nil
    end
    RequestModel(hash)
    local timeout = GetGameTimer() + 5000
    while not HasModelLoaded(hash) do
        if GetGameTimer() > timeout then return nil end
        Wait(10)
    end
    return hash
end

local function LoadAnim(dict)
    RequestAnimDict(dict)
    local timeout = GetGameTimer() + 4000
    while not HasAnimDictLoaded(dict) do
        if GetGameTimer() > timeout then return false end
        Wait(10)
    end
    return true
end

local function FindRoadSpawn(origin)
    local best, bestScore
    local preferred = Config.Medic.spawnDistance or 85.0
    for i = 1, 12 do
        local angle = (i / 12.0) * math.pi * 2.0
        local probe = vector3(
            origin.x + math.cos(angle) * preferred,
            origin.y + math.sin(angle) * preferred,
            origin.z
        )
        local found, node = GetClosestVehicleNodeWithHeading(probe.x, probe.y, probe.z, 1, 3.0, 0)
        if found and node then
            local dist = #(origin - node)
            if dist > 28.0 then
                local score = math.abs(dist - preferred)
                if not bestScore or score < bestScore then
                    best = node
                    bestScore = score
                end
            end
        end
    end

    if best then
        return best, GetHeadingFromVector_2d(origin.x - best.x, origin.y - best.y)
    end

    return vector3(origin.x + 40.0, origin.y + 18.0, origin.z), 0.0
end

local function RoadNear(origin)
    local found, node = GetClosestVehicleNodeWithHeading(origin.x, origin.y, origin.z, 1, 3.0, 0)
    if found and node and #(origin - node) < 90.0 then
        return node
    end
    return origin
end

ParkAmbulance = function(veh, near)
    if not veh or not DoesEntityExist(veh) then return end
    local park = RoadNear(near)
    if #(park - near) < 12.0 then
        local heading = GetEntityHeading(PlayerPedId())
        local rad = math.rad(heading)
        park = vector3(near.x - math.sin(rad) * 16.0, near.y + math.cos(rad) * 16.0, near.z)
    end
    SetEntityCoords(veh, park.x, park.y, park.z, false, false, false, false)
    SetVehicleOnGroundProperly(veh)
    SetVehicleEngineOn(veh, true, true, false)
    SetVehicleDoorsLocked(veh, 1)
    SetVehicleSiren(veh, false)
    HoldVehicle(veh)
end

EnsureAmbulance = function(unit, near)
    if not unit then return nil end
    if unit.veh and DoesEntityExist(unit.veh) then
        HoldVehicle(unit.veh)
        return unit.veh
    end

    local hash = LoadModel(Config.Medic.vehicle)
    if not hash or not near then return nil end
    local heading = GetEntityHeading(PlayerPedId())
    local rad = math.rad(heading)
    local veh = CreateVehicle(hash, near.x - math.sin(rad) * 14.0, near.y + math.cos(rad) * 14.0, near.z, heading, true, true)
    SetModelAsNoLongerNeeded(hash)
    if not DoesEntityExist(veh) then return nil end

    HoldVehicle(veh)
    SetVehicleOnGroundProperly(veh)
    SetVehicleEngineOn(veh, true, true, false)
    SetVehicleSiren(veh, false)
    SetVehicleDoorsLocked(veh, 1)
    if ParkAmbulance then
        ParkAmbulance(veh, near)
    end
    unit.veh = veh

    if not unit.blip or not DoesBlipExist(unit.blip) then
        local blip = AddBlipForEntity(veh)
        SetBlipSprite(blip, 61)
        SetBlipColour(blip, 1)
        SetBlipScale(blip, 0.85)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString('Medic')
        EndTextCommandSetBlipName(blip)
        unit.blip = blip
    end
    return veh
end

local function MetaCleared()
    local death = DeathState()
    if death and death ~= 1 then return false end
    local data = PlayerData()
    local meta = data and data.metadata or {}
    return not meta.isdead and not meta.inlaststand
end

local function StillDown()
    local ped = PlayerPedId()
    if IsEntityDead(ped) or IsPedFatallyInjured(ped) then return true end
    if IsEntityPlayingAnim(ped, 'combat@damage@writhe', 'writhe_loop', 3) then return true end
    if IsEntityPlayingAnim(ped, 'dead', 'dead_a', 3) then return true end
    if IsEntityPlayingAnim(ped, 'dead', 'dead_b', 3) then return true end
    if IsEntityPlayingAnim(ped, 'veh@low@front_ps@idle_duck', 'sit', 3) then return true end
    return false
end

local function GroundAt(x, y, z, ignore)
    local ok, result = pcall(function()
        local handle = StartExpensiveSynchronousShapeTestLosProbe(x, y, z + 0.8, x, y, z - 2.2, 17, ignore or 0, 4)
        local _, hit, endCoords = GetShapeTestResult(handle)
        if hit == 1 and endCoords and math.abs(endCoords.z - z) <= 1.6 then
            return endCoords.z
        end
        return z
    end)
    if ok and result then return result end
    return z
end

local function FireAmbulanceRevive()
    if Framework.Medical() == 'qbox' then return end
    if not Config.UseAmbulanceJob then return end
    TriggerEvent(Config.ReviveEvent or 'hospital:client:Revive')
end

local function RaiseHealth(health)
    local ped = PlayerPedId()
    SetEntityMaxHealth(ped, 200)
    SetEntityHealth(ped, health or Config.ReviveHealth)
    ClearPedBloodDamage(ped)
    SetEntityInvincible(ped, false)
    SetPlayerInvincible(PlayerId(), false)
    ResetPedMovementClipset(ped, 0.0)
    SetPlayerSprint(PlayerId(), true)
    EnableAllControlActions(0)
end

local function ReviveQbox(health)
    local deadline = GetGameTimer() + 2500
    if DeathState() and DeathState() ~= 1 then
        TriggerEvent('qbx_medical:client:playerRevived')
    end
    while DeathState() and DeathState() ~= 1 and GetGameTimer() < deadline do
        Wait(100)
    end
    if DeathState() and DeathState() ~= 1 then
        TriggerEvent('qbx_medical:client:playerRevived')
        Wait(200)
    end
    RaiseHealth(health)
end

local function HardStand(health)
    local ped = PlayerPedId()
    if not IsEntityDead(ped) and not IsPedFatallyInjured(ped) then
        SetEntityHealth(ped, health or Config.ReviveHealth)
        ClearPedTasksImmediately(ped)
        SetEntityInvincible(ped, false)
        SetPlayerInvincible(PlayerId(), false)
        EnableAllControlActions(0)
        return
    end

    local coords = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)
    NetworkResurrectLocalPlayer(coords.x, coords.y, coords.z, heading, true, false)
    ped = PlayerPedId()
    SetEntityMaxHealth(ped, 200)
    SetEntityHealth(ped, health or Config.ReviveHealth)
    ClearPedTasksImmediately(ped)
    ClearPedBloodDamage(ped)
    SetEntityInvincible(ped, false)
    SetPlayerInvincible(PlayerId(), false)
    SetPedCanRagdoll(ped, true)
    ResetPedMovementClipset(ped, 0.0)
    SetPlayerSprint(PlayerId(), true)
    EnableAllControlActions(0)
    if IsScreenFadedOut() or IsScreenFadingOut() then
        DoScreenFadeIn(800)
    end
    TriggerServerEvent('hospital:server:SetDeathStatus', false)
    TriggerServerEvent('hospital:server:SetLaststandStatus', false)
end

local function ReviveEsx(health)
    local deadline = GetGameTimer() + 2500
    while (IsEntityDead(PlayerPedId()) or IsPedFatallyInjured(PlayerPedId())) and GetGameTimer() < deadline do
        Wait(100)
    end
    if StillDown() then
        HardStand(health)
    else
        RaiseHealth(health)
    end
end

local function SnapMedicToPlayer(unit)
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local heading = GetEntityHeading(playerPed)
    local rad = math.rad(heading)
    local x = coords.x + (math.cos(rad) * 0.8)
    local y = coords.y + (math.sin(rad) * 0.8)
    local z = GroundAt(x, y, coords.z, playerPed)
    if z > coords.z + 0.15 then z = coords.z end
    if coords.z - z > 1.25 then z = coords.z end

    local medicPed = unit.ped
    if unit.veh and DoesEntityExist(unit.veh) then
        ParkAmbulance(unit.veh, coords)
        HoldVehicle(unit.veh)
    else
        EnsureAmbulance(unit, coords)
    end

    if not medicPed or not DoesEntityExist(medicPed) then
        local hash = LoadModel(Config.Medic.model)
        if not hash then return nil end
        medicPed = CreatePed(4, hash, x, y, z, heading, true, true)
        SetModelAsNoLongerNeeded(hash)
        if not DoesEntityExist(medicPed) then return nil end
        SetEntityAsMissionEntity(medicPed, true, true)
        SetBlockingOfNonTemporaryEvents(medicPed, true)
        SetPedFleeAttributes(medicPed, 0, false)
        SetPedCanRagdoll(medicPed, false)
        SetEntityInvincible(medicPed, true)
        unit.ped = medicPed
    end

    ClearPedTasksImmediately(medicPed)
    SetEntityCoords(medicPed, x, y, z, false, false, false, false)
    SetEntityHeading(medicPed, GetHeadingFromVector_2d(coords.x - x, coords.y - y))
    SetEntityNoCollisionEntity(medicPed, playerPed, true)
    FreezeEntityPosition(medicPed, false)
    return medicPed
end

local function RunMedic(runId)
    local origin = GetEntityCoords(PlayerPedId())
    local spawn, heading = FindRoadSpawn(origin)
    local vehHash = LoadModel(Config.Medic.vehicle)
    local pedHash = LoadModel(Config.Medic.model)
    if not vehHash or not pedHash then
        return false, 'model'
    end

    RequestCollisionAtCoord(spawn.x, spawn.y, spawn.z)
    local veh = CreateVehicle(vehHash, spawn.x, spawn.y, spawn.z, heading, true, true)
    if not DoesEntityExist(veh) then
        SetModelAsNoLongerNeeded(vehHash)
        SetModelAsNoLongerNeeded(pedHash)
        return false, 'spawn'
    end

    SetEntityAsMissionEntity(veh, true, true)
    HoldVehicle(veh)
    SetVehicleOnGroundProperly(veh)
    SetVehicleEngineOn(veh, true, true, false)
    SetVehicleSiren(veh, Config.Medic.siren == true)
    SetVehRadioStation(veh, 'OFF')
    SetVehicleDoorsLocked(veh, 2)
    SetEntityHeading(veh, heading)

    local medicPed = CreatePedInsideVehicle(veh, 4, pedHash, -1, true, true)
    if not DoesEntityExist(medicPed) then
        medicPed = CreatePed(4, pedHash, spawn.x, spawn.y, spawn.z, heading, true, true)
        if DoesEntityExist(medicPed) then
            SetPedIntoVehicle(medicPed, veh, -1)
        end
    end

    SetModelAsNoLongerNeeded(vehHash)
    SetModelAsNoLongerNeeded(pedHash)

    if not DoesEntityExist(medicPed) then
        DeleteEntity(veh)
        return false, 'spawn'
    end

    SetEntityAsMissionEntity(medicPed, true, true)
    SetBlockingOfNonTemporaryEvents(medicPed, true)
    SetPedFleeAttributes(medicPed, 0, false)
    SetPedCanRagdoll(medicPed, false)
    SetEntityInvincible(medicPed, true)
    SetPedKeepTask(medicPed, true)
    SetDriverAbility(medicPed, 1.0)
    SetDriverAggressiveness(medicPed, 0.35)

    local blip = AddBlipForEntity(veh)
    SetBlipSprite(blip, 61)
    SetBlipColour(blip, 1)
    SetBlipScale(blip, 0.85)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString('Medic')
    EndTextCommandSetBlipName(blip)

    local unit = Track({ ped = medicPed, veh = veh, blip = blip, runId = runId })
    local dest = RoadNear(GetEntityCoords(PlayerPedId()))
    TaskVehicleDriveToCoord(medicPed, veh, dest.x, dest.y, dest.z, Config.Medic.driveSpeed or 20.0, 0, vehHash, 787004, 6.0, true)

    local respondBy = GetGameTimer() + ((Config.Medic.arriveTimeout or 30) * 1000)
    local lastPos = GetEntityCoords(veh)
    local lastMove = GetGameTimer()
    local lastPing = 0
    local arrived = false
    local retasks = 0

    while GetGameTimer() < respondBy do
        if runId ~= currentRun then
            DeleteUnitNow(unit)
            return false, 'cancel'
        end
        if not DoesEntityExist(veh) or not DoesEntityExist(medicPed) then
            break
        end
        HoldVehicle(veh)

        local playerCoords = GetEntityCoords(PlayerPedId())
        local vehCoords = GetEntityCoords(veh)
        local distPlayer = #(vehCoords - playerCoords)

        if GetGameTimer() - lastPing > 1000 then
            lastPing = GetGameTimer()
            SendUI({ action = 'distance', meters = math.floor(distPlayer) })
        end

        if distPlayer < (Config.Medic.arriveRadius or 16.0) then
            arrived = true
            break
        end

        if #(vehCoords - lastPos) > 2.5 then
            lastPos = vehCoords
            lastMove = GetGameTimer()
        elseif GetGameTimer() - lastMove > 8000 then
            retasks = retasks + 1
            TaskVehicleDriveToCoord(medicPed, veh, playerCoords.x, playerCoords.y, playerCoords.z, Config.Medic.driveSpeed or 20.0, 0, vehHash, 787004, 6.0, true)
            lastMove = GetGameTimer()
            lastPos = GetEntityCoords(veh)
        end

        Wait(400)
    end

    if not arrived then
        medicPed = SnapMedicToPlayer(unit)
        if not medicPed then
            DeleteUnitNow(unit)
            return false, 'spawn'
        end
    else
        if DoesEntityExist(veh) and DoesEntityExist(medicPed) then
            TaskVehicleTempAction(medicPed, veh, 27, 1500)
            Wait(500)
            TaskLeaveVehicle(medicPed, veh, 0)
            local leaveDeadline = GetGameTimer() + 4000
            while DoesEntityExist(medicPed) and IsPedInVehicle(medicPed, veh, false) and GetGameTimer() < leaveDeadline do
                Wait(100)
            end
            if DoesEntityExist(medicPed) and DoesEntityExist(veh) and IsPedInVehicle(medicPed, veh, false) then
                TaskLeaveVehicle(medicPed, veh, 16)
                Wait(300)
            end
        end

        if runId ~= currentRun then
            DeleteUnitNow(unit)
            return false, 'cancel'
        end

        if DoesEntityExist(medicPed) then
            TaskGoToEntity(medicPed, PlayerPedId(), -1, 0.85, 1.35, 0.0, 0)
        end
        local walkDeadline = GetGameTimer() + 8000
        local reached = false
        while GetGameTimer() < walkDeadline do
            if runId ~= currentRun or not DoesEntityExist(medicPed) then
                DeleteUnitNow(unit)
                return false, 'cancel'
            end
            if #(GetEntityCoords(medicPed) - GetEntityCoords(PlayerPedId())) < 1.8 then
                reached = true
                break
            end
            if DoesEntityExist(veh) then
                HoldVehicle(veh)
            end
            if GetGameTimer() >= respondBy then
                break
            end
            Wait(200)
        end

        if not reached then
            medicPed = SnapMedicToPlayer(unit)
            if not medicPed then
                DeleteUnitNow(unit)
                return false, 'spawn'
            end
        end
    end

    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local playerHeading = GetEntityHeading(playerPed)
    local rad = math.rad(playerHeading)
    local standX = playerCoords.x + (math.cos(rad) * 0.7)
    local standY = playerCoords.y + (math.sin(rad) * 0.7)
    local standZ = GroundAt(standX, standY, playerCoords.z, playerPed)
    if standZ > playerCoords.z + 0.15 then standZ = playerCoords.z end
    if playerCoords.z - standZ > 1.25 then standZ = playerCoords.z end

    ClearPedTasksImmediately(medicPed)
    SetEntityCoords(medicPed, standX, standY, standZ, false, false, false, false)
    SetEntityHeading(medicPed, GetHeadingFromVector_2d(playerCoords.x - standX, playerCoords.y - standY))
    FreezeEntityPosition(medicPed, false)
    SetEntityNoCollisionEntity(medicPed, playerPed, true)
    SetBlockingOfNonTemporaryEvents(medicPed, true)
    EnsureAmbulance(unit, playerCoords)

    local introDict = 'mini@cpr@char_a@cpr_def'
    local pumpDict = 'mini@cpr@char_a@cpr_str'
    local hasIntro = LoadAnim(introDict)
    local hasPump = LoadAnim(pumpDict)

    phase = 'treating'
    TriggerServerEvent('tees-npcmedic:server:treatment')
    local duration = (Config.TreatTime or 12) * 1000
    local lines = Config.MedicTalk or {}
    SendUI({ action = 'treat', duration = duration, lines = lines })
    medicTalk = {
        ped = medicPed,
        lines = lines,
        started = GetGameTimer(),
        duration = duration,
    }

    local started = GetGameTimer()
    local treatEnd = started + duration
    if hasIntro and DoesEntityExist(medicPed) then
        TaskPlayAnim(medicPed, introDict, 'cpr_intro', 8.0, 1.0, -1, 0, 0.0, false, false, false)
    end

    while GetGameTimer() < treatEnd do
        if runId ~= currentRun then
            medicTalk = nil
            DeleteUnitNow(unit)
            return false, 'cancel'
        end
        if DoesEntityExist(medicPed) then
            local elapsed = GetGameTimer() - started
            if hasPump and elapsed >= 2800 then
                if not IsEntityPlayingAnim(medicPed, pumpDict, 'cpr_pumpchest', 3) then
                    TaskPlayAnim(medicPed, pumpDict, 'cpr_pumpchest', 8.0, 1.0, -1, 1, 0.0, false, false, false)
                end
            elseif hasIntro and not IsEntityPlayingAnim(medicPed, introDict, 'cpr_intro', 3) then
                TaskPlayAnim(medicPed, introDict, 'cpr_intro', 8.0, 1.0, -1, 0, 0.0, false, false, false)
            end
        end
        if unit.veh and DoesEntityExist(unit.veh) then
            HoldVehicle(unit.veh)
        elseif GetGameTimer() - started > 1000 then
            EnsureAmbulance(unit, GetEntityCoords(PlayerPedId()))
        end
        Wait(300)
    end

    if DoesEntityExist(medicPed) then
        FreezeEntityPosition(medicPed, false)
        ClearPedTasks(medicPed)
    end
    medicTalk = nil

    phase = 'recovering'
    TriggerServerEvent('tees-npcmedic:server:finish')
    DismissUnit(unit)

    local finishedRun = runId
    SetTimeout(5000, function()
        if phase == 'recovering' and finishedRun == currentRun and IsLocalDown() then
            phase = 'ready'
            reported = true
            SendUI({ action = 'ready' })
            Notify('The revive did not register. Press E to call again.', 'error')
        end
    end)
    return true
end

local function AbortLocal()
    previewing = false
    currentRun = currentRun + 1
    local snapshot = {}
    for unit in pairs(units) do
        snapshot[#snapshot + 1] = unit
    end
    for i = 1, #snapshot do
        DeleteUnitNow(snapshot[i])
    end
    if phase == 'enroute' or phase == 'treating' or phase == 'calling' then
        TriggerServerEvent('tees-npcmedic:server:cancel')
    end
    phase = 'idle'
    reported = false
    CloseUI()
end

RegisterNetEvent('tees-npcmedic:client:ignored', function()
    if phase == 'idle' then
        reported = false
    end
end)

local function StartLockout(remaining, delay)
    remaining = tonumber(remaining) or Config.CallDelay
    delay = tonumber(delay) or Config.CallDelay
    phase = remaining > 0 and 'waiting' or 'ready'
    OpenUI(remaining, delay)

    if phase ~= 'waiting' then
        SendUI({ action = 'ready' })
        return
    end

    local token = currentRun
    local ends = GetGameTimer() + math.floor(remaining * 1000)
    CreateThread(function()
        while phase == 'waiting' and token == currentRun do
            if GetGameTimer() >= ends then
                if phase == 'waiting' then
                    phase = 'ready'
                    SendUI({ action = 'ready' })
                end
                return
            end
            Wait(150)
        end
    end)
end

RegisterNetEvent('tees-npcmedic:client:begin', function(remaining, delay)
    if not IsLocalDown() then
        reported = false
        TriggerServerEvent('tees-npcmedic:server:cancel')
        return
    end

    StartLockout(remaining, delay)
end)

RegisterNetEvent('tees-npcmedic:client:dispatch', function()
    phase = 'enroute'
    currentRun = currentRun + 1
    local runId = currentRun
    SendUI({ action = 'enroute' })
    Notify(Config.Text.called, 'success')

    CreateThread(function()
        local ok, reason = RunMedic(runId)
        if ok or reason == 'cancel' or runId ~= currentRun then
            return
        end
        phase = 'ready'
        SendUI({ action = 'ready' })
        TriggerServerEvent('tees-npcmedic:server:failed')
    end)
end)

RegisterNetEvent('tees-npcmedic:client:rejected', function(remaining)
    if phase == 'calling' then
        if remaining and tonumber(remaining) and tonumber(remaining) > 0 then
            StartLockout(tonumber(remaining), Config.CallDelay)
        else
            phase = 'ready'
            SendUI({ action = 'ready' })
        end
    end
end)

RegisterNetEvent('tees-npcmedic:client:revive', function(health, medical)
    phase = 'recovering'
    local targetHealth = health or Config.ReviveHealth
    medical = medical or Framework.Medical()

    if medical == 'qbox' then
        ReviveQbox(targetHealth)
    elseif medical == 'esx' or medical == 'esx_death' then
        ReviveEsx(targetHealth)
    else
        local metaDeadline = GetGameTimer() + 2500
        while not MetaCleared() and GetGameTimer() < metaDeadline do
            Wait(100)
        end

        FireAmbulanceRevive()
        Wait(500)
        if StillDown() then
            HardStand(targetHealth)
            FireAmbulanceRevive()
        else
            RaiseHealth(targetHealth)
        end
    end

    SendUI({ action = 'revived' })
    Notify(Config.Text.revived, 'success')

    local guardUntil = GetGameTimer() + 3000
    CreateThread(function()
        while GetGameTimer() < guardUntil do
            if phase ~= 'recovering' then return end
            if medical == 'qbox' then
                if DeathState() and DeathState() ~= 1 then
                    TriggerEvent('qbx_medical:client:playerRevived')
                    RaiseHealth(targetHealth)
                end
            elseif StillDown() then
                FireAmbulanceRevive()
                if not IsEntityDead(PlayerPedId()) then
                    RaiseHealth(targetHealth)
                    ClearPedTasksImmediately(PlayerPedId())
                end
            end
            Wait(400)
        end

        if phase ~= 'recovering' then return end
        local stillDown = medical == 'qbox' and DeathState() and DeathState() ~= 1 or StillDown()
        if stillDown then
            phase = 'ready'
            reported = true
            SendUI({ action = 'ready' })
            Notify('The revive did not stick. Press E to call again.', 'error')
            return
        end
        phase = 'idle'
        reported = false
        CloseUI()
    end)
end)

local watchReadyAt = 0

local function CanWatchDeath()
    if not IsLoaded() then return false end
    return GetGameTimer() >= watchReadyAt
end

local function OnPlayerLoaded()
    watchReadyAt = GetGameTimer() + 8000
    if phase ~= 'enroute' and phase ~= 'treating' and phase ~= 'recovering' then
        previewing = false
        phase = 'idle'
        reported = false
        CloseUI()
    end
end

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', OnPlayerLoaded)
RegisterNetEvent('esx:playerLoaded', OnPlayerLoaded)

local function DrawBubble(cx, cy, w, h, r, g, b, a)
    local radius = 0.0032
    DrawRect(cx, cy, math.max(0.001, w - radius * 2), h, r, g, b, a)
    DrawRect(cx, cy, w, math.max(0.001, h - radius * 2), r, g, b, a)
end

local function DrawMedicLine(text, coords)
    local onScreen, sx, sy = World3dToScreen2d(coords.x, coords.y, coords.z + 1.18)
    if not onScreen then return end

    SetTextFont(4)
    SetTextScale(0.32, 0.32)
    SetTextProportional(true)
    SetTextCentre(true)
    BeginTextCommandGetWidth('STRING')
    AddTextComponentSubstringPlayerName(text)
    local width = EndTextCommandGetWidth(true)
    if not width or width < 0.05 then width = 0.05 end

    local boxW = width + 0.022
    local boxH = 0.036
    local edgeW = boxW + 0.003
    local edgeH = boxH + 0.005

    DrawBubble(sx, sy, edgeW, edgeH, 61, 222, 173, 210)
    DrawBubble(sx, sy, boxW, boxH, 7, 12, 11, 230)

    local base = sy + (boxH / 2)
    DrawRect(sx, base + 0.005, 0.016, 0.008, 61, 222, 173, 210)
    DrawRect(sx, base + 0.005, 0.011, 0.007, 7, 12, 11, 230)
    DrawRect(sx, base + 0.011, 0.007, 0.008, 7, 12, 11, 230)
    DrawRect(sx, base + 0.017, 0.0035, 0.007, 7, 12, 11, 230)

    SetTextColour(237, 244, 241, 245)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(sx, sy - 0.0115)
end

CreateThread(function()
    while true do
        local talk = medicTalk
        if talk and phase == 'treating' and talk.ped and DoesEntityExist(talk.ped) and talk.lines and #talk.lines > 0 then
            local elapsed = GetGameTimer() - talk.started
            local index = math.floor((elapsed / math.max(talk.duration, 1)) * #talk.lines) + 1
            if index < 1 then index = 1 end
            if index > #talk.lines then index = #talk.lines end
            DrawMedicLine(talk.lines[index], GetEntityCoords(talk.ped))
            Wait(0)
        else
            Wait(250)
        end
    end
end)

local voiceDown = false
local nextVoiceSync = 0

local function SyncVoice(down)
    if not Config.MuteWhileDead or previewing then return end
    local now = GetGameTimer()
    if down ~= voiceDown then
        voiceDown = down
        nextVoiceSync = now + 2000
        TriggerServerEvent('tees-npcmedic:server:syncVoice')
        return
    end
    if down and now >= nextVoiceSync then
        nextVoiceSync = now + 2000
        TriggerServerEvent('tees-npcmedic:server:syncVoice')
    end
end

RegisterNetEvent('tees-npcmedic:client:voice', function(muted)
    if GetResourceState('saltychat') ~= 'started' then return end
    pcall(function()
        exports['saltychat']:SetPlayerAlive(not muted)
    end)
end)

CreateThread(function()
    while true do
        local loggedIn = IsLoaded()
        if loggedIn then
            SyncVoice(IsLocalDown())
        end
        if not CanWatchDeath() then
            Wait(500)
        else
        local down = IsLocalDown()
        if down and not reported and phase == 'idle' then
            reported = true
            TriggerServerEvent('tees-npcmedic:server:downed')
            Wait(500)
        elseif not down and not previewing and phase ~= 'idle' and phase ~= 'recovering' and phase ~= 'treating' and phase ~= 'enroute' then
            AbortLocal()
            Wait(400)
        else
            Wait(phase == 'idle' and 500 or 300)
        end
        end
    end
end)

CreateThread(function()
    while true do
        if phase == 'ready' then
            if not previewing and not IsPauseMenuActive() and (IsControlJustPressed(0, 38) or IsDisabledControlJustPressed(0, 38)) then
                phase = 'calling'
                TriggerServerEvent('tees-npcmedic:server:request')
                SetTimeout(8000, function()
                    if phase == 'calling' then
                        phase = 'ready'
                        SendUI({ action = 'ready' })
                        Notify('Dispatch did not answer. Try again.', 'error')
                    end
                end)
            end
            Wait(0)
        else
            Wait(250)
        end
    end
end)

RegisterCommand('npcmedicui', function()
    if not Config.EnablePreviewCommand then return end
    if previewing then
        previewing = false
        phase = 'idle'
        reported = false
        CloseUI()
        return
    end
    previewing = true
    phase = 'waiting'
    reported = true
    OpenUI(Config.CallDelay, Config.CallDelay)
    local ends = GetGameTimer() + (Config.CallDelay * 1000)
    CreateThread(function()
        while previewing and phase == 'waiting' and GetGameTimer() < ends do
            Wait(150)
        end
        if previewing and phase == 'waiting' then
            phase = 'ready'
            SendUI({ action = 'ready' })
        end
    end)
end, false)

RegisterNUICallback('ready', function(_, cb)
    cb(uiState)
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    local snapshot = {}
    for unit in pairs(units) do
        snapshot[#snapshot + 1] = unit
    end
    for unit in pairs(lingering) do
        snapshot[#snapshot + 1] = unit
    end
    for i = 1, #snapshot do
        DeleteUnitNow(snapshot[i])
    end
    CloseUI()
end)
