Framework = {}

local cachedName
local cachedObject

local function resourceUp(name)
    local state = GetResourceState(name)
    return state == 'started' or state == 'starting'
end

function Framework.Name()
    local forced = Config.Framework
    if forced and forced ~= '' and forced ~= 'auto' then
        if forced == 'qbcore' then return 'qb' end
        return forced
    end
    if cachedName then return cachedName end
    if resourceUp('qbx_core') then
        cachedName = 'qbox'
    elseif resourceUp('qb-core') then
        cachedName = 'qb'
    elseif resourceUp('es_extended') then
        cachedName = 'esx'
    else
        return 'unknown'
    end
    return cachedName
end

-- Which medical resource should actually clear death and bleed.
function Framework.Medical()
    if resourceUp('qbx_medical') then return 'qbox' end
    if resourceUp('esx_death') then return 'esx_death' end
    if resourceUp('esx_ambulancejob') then return 'esx' end
    if resourceUp('qb-ambulancejob') then return 'qb' end
    return Framework.Name()
end

function Framework.Object()
    if cachedObject then return cachedObject end
    local name = Framework.Name()
    if name == 'qb' or name == 'qbox' then
        local ok, obj = pcall(function()
            return exports['qb-core']:GetCoreObject()
        end)
        if ok and obj then
            cachedObject = obj
        end
        return cachedObject
    end
    if name == 'esx' then
        local ok, obj = pcall(function()
            return exports['es_extended']:getSharedObject()
        end)
        if ok and obj then
            cachedObject = obj
        end
        return cachedObject
    end
end

function Framework.Account(account)
    if Framework.Name() == 'esx' and (account == 'cash' or account == 'money') then
        return 'money'
    end
    return account
end
