fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'tees-npcmedic'
author 'Tees'
description 'NPC medic for Qbox, QBCore, and ESX — death lockout, live pulse, and revive'
version '1.1.1'

escrow_ignore {
    'config.lua',
}

shared_scripts {
    'config.lua',
    'shared/framework.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
}

-- Starts on Qbox, QBCore, or ESX. No hard dependency so any of the three can load it.
