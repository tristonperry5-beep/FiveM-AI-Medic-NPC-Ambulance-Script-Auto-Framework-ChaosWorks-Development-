Config = {}

-- auto, qbox, qb, or esx. auto uses whichever core is running.
-- Qbox is checked before QBCore, because Qbox also provides qb-core.
Config.Framework = 'auto'

-- Seconds the player must stay down before E will call a medic.
Config.CallDelay = 30

-- How long CPR takes, in seconds. The progress bar and his lines use this same duration.
Config.TreatTime = 25

-- Health applied when the medic finishes. Qbox and QBCore use 200 as full.
Config.ReviveHealth = 200

-- On QBCore, also fire the ambulance revive so bleed-out and laststand clear.
-- Qbox uses qbx_medical and ESX uses esx_ambulancejob / esx_death on their own.
Config.UseAmbulanceJob = true
Config.ReviveEvent = 'hospital:client:Revive'

-- Count laststand (downed, not fully dead) as a valid call state.
Config.IncludeLaststand = true

-- Mute proximity and radio voice while the player is dead or bleeding out.
Config.MuteWhileDead = true

-- Fee taken when the medic is dispatched. Tries cash first, then bank.
-- Refunded if the revive does not go through.
Config.Cost = 100000
Config.Account = 'cash'
Config.FallbackAccount = 'bank'

-- Seconds after a successful revive before another NPC medic can be called.
Config.Cooldown = 0

-- If on-duty EMS reach this number, the NPC refuses. -1 disables the check.
Config.EmsJob = 'ambulance'
Config.MaxOnDutyEms = -1

-- Monitor beep in the death UI.
Config.Sound = true

Config.Medic = {
    model = 's_m_m_paramedic_01',
    vehicle = 'ambulance',
    siren = true,
    spawnDistance = 85.0,   -- how far out the ambulance spawns, in meters
    driveSpeed = 20.0,
    arriveRadius = 16.0,
    arriveTimeout = 25,    -- seconds before the medic and ambulance are placed beside you
}

Config.Text = {
    called = 'A medic is on the way.',
    revived = 'The field medic brought you back.',
    failed = 'The medic could not reach you. Any fee was returned.',
    noMoney = 'You need $100,000 in cash or bank to call a medic.',
    emsOnline = 'EMS are on duty. Reach them instead of the NPC medic.',
    tooSoon = 'You are still too critical to call. Wait for the monitor.',
    cooldown = 'The field unit is not available yet.',
    already = 'A medic is already responding.',
}

-- Spoken lines, in order, across the revive. Edit these to change what he says.
Config.MedicTalk = {
    'Hey. Can you hear me? Stay with me.',
    'Checking your airway. Don\'t move.',
    'Airway is clear. I\'m checking for a pulse.',
    'Pulse is there, but it\'s weak.',
    'You\'re bleeding. I\'m packing that now.',
    'Starting compressions. One, two, three...',
    'Keep going. Come on, breathe for me.',
    'I\'ve got a rhythm. Stay with it.',
    'Pupils are responding. Almost there.',
    'You\'re coming back. Easy, easy.',
    'That\'s it. You\'re stable. I\'ve got you.',
}

-- Dev only. /npcmedicui opens the monitor without killing the player.
Config.EnablePreviewCommand = false
